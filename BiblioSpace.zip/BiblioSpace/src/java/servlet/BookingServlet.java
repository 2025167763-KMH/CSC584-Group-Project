package servlet;

import java.io.IOException;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet(name = "BookingServlet", urlPatterns = {"/BookingServlet"})
public class BookingServlet extends HttpServlet {

    private static final String DB_URL = "jdbc:derby://localhost:1527/BiblioDB";
    private static final String DB_USER = "Biblio";
    private static final String DB_PASSWORD = "password";

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("student_ID") == null) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        int studentID = (Integer) session.getAttribute("student_ID");
        int roomID = Integer.parseInt(request.getParameter("room_ID"));
        String bookDateStr = request.getParameter("book_date");   // yyyy-MM-dd
        String startTimeStr = request.getParameter("start_time") + ":00"; // HH:mm:ss
        String endTimeStr = request.getParameter("end_time") + ":00";     // HH:mm:ss

        Date bookDate = Date.valueOf(bookDateStr);
        Time startTime = Time.valueOf(startTimeStr);
        Time endTime = Time.valueOf(endTimeStr);

        if (!endTime.after(startTime)) {
            request.setAttribute("errorMessage", "End time must be after start time.");
            request.getRequestDispatcher("booking.jsp").forward(request, response);
            return;
        }

        Connection conn = null;
        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            // 1. Check if room is already booked during overlapping time on that date
            String conflictSql = "SELECT booking_ID FROM Bookings WHERE room_ID = ? AND book_date = ? AND status = 'Upcoming' " +
                                 "AND (start_time < ? AND end_time > ?)";
            PreparedStatement checkStmt = conn.prepareStatement(conflictSql);
            checkStmt.setInt(1, roomID);
            checkStmt.setDate(2, bookDate);
            checkStmt.setTime(3, endTime);
            checkStmt.setTime(4, startTime);
            ResultSet rs = checkStmt.executeQuery();

            if (rs.next()) {
                rs.close(); checkStmt.close();
                request.setAttribute("errorMessage", "This room is already reserved for that date and time slot.");
                request.getRequestDispatcher("booking.jsp").forward(request, response);
                return;
            }
            rs.close();
            checkStmt.close();

            // 2. Insert into Bookings table
            String insertSql = "INSERT INTO Bookings (student_ID, room_ID, start_time, end_time, book_date, status) VALUES (?, ?, ?, ?, ?, 'Upcoming')";
            PreparedStatement insertStmt = conn.prepareStatement(insertSql);
            insertStmt.setInt(1, studentID);
            insertStmt.setInt(2, roomID);
            insertStmt.setTime(3, startTime);
            insertStmt.setTime(4, endTime);
            insertStmt.setDate(5, bookDate);
            insertStmt.executeUpdate();
            insertStmt.close();

            // 3. Insert/Update Rooms_status table (Composite PK: room_ID + booking_date)
            String statusCheckSql = "SELECT Room_status FROM Rooms_status WHERE room_ID = ? AND booking_date = ?";
            PreparedStatement stCheck = conn.prepareStatement(statusCheckSql);
            stCheck.setInt(1, roomID);
            stCheck.setDate(2, bookDate);
            ResultSet stRs = stCheck.executeQuery();

            if (!stRs.next()) {
                String statusInsertSql = "INSERT INTO Rooms_status (room_ID, booking_date, Room_status) VALUES (?, ?, 'Reserved')";
                PreparedStatement stInsert = conn.prepareStatement(statusInsertSql);
                stInsert.setInt(1, roomID);
                stInsert.setDate(2, bookDate);
                stInsert.executeUpdate();
                stInsert.close();
            }
            stRs.close();
            stCheck.close();

            // Redirect to History page
            response.sendRedirect(request.getContextPath() + "/mybooking.jsp?booked=true");

        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "Booking error: " + e.getMessage());
            request.getRequestDispatcher("booking.jsp").forward(request, response);
        } finally {
            try { if (conn != null) conn.close(); } catch (SQLException ignored) {}
        }
    }
}