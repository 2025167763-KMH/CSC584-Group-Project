package servlet;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "registerServlet", urlPatterns = {"/registerServlet"})
public class registerServlet extends HttpServlet {

    // Matches your NetBeans connection: jdbc:derby://localhost:1527/BiblioDB [Biblio on BIBLIO]
    private static final String DB_URL = "jdbc:derby://localhost:1527/BiblioDB";
    private static final String DB_USER = "Biblio";
    private static final String DB_PASSWORD = "password";

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // 1. Retrieve form parameters matching your ERD column names
        String studentIDStr = request.getParameter("student_ID");
        String studentFname = request.getParameter("student_Fname");
        String studentLname = request.getParameter("student_Lname");
        String password = request.getParameter("password");
        String confirmPassword = request.getParameter("confirmPassword");

        // 2. Basic server-side validation
        if (studentIDStr == null || studentIDStr.trim().isEmpty() ||
            studentFname == null || studentFname.trim().isEmpty() ||
            studentLname == null || studentLname.trim().isEmpty() ||
            password == null || password.trim().isEmpty()) {

            request.setAttribute("errorMessage", "All fields are required.");
            request.getRequestDispatcher("register.jsp").forward(request, response);
            return;
        }

        if (!password.equals(confirmPassword)) {
            request.setAttribute("errorMessage", "Passwords do not match!");
            request.getRequestDispatcher("register.jsp").forward(request, response);
            return;
        }

        int studentID;
        try {
            studentID = Integer.parseInt(studentIDStr.trim());
        } catch (NumberFormatException e) {
            request.setAttribute("errorMessage", "Student ID must be numbers only.");
            request.getRequestDispatcher("register.jsp").forward(request, response);
            return;
        }

        Connection conn = null;
        PreparedStatement checkStmt = null;
        PreparedStatement insertStmt = null;
        ResultSet rs = null;

        try {
            // Load NetBeans Java DB (Apache Derby) Driver
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            // 3. Check if student_ID already exists in 'students' table
            String checkQuery = "SELECT student_ID FROM students WHERE student_ID = ?";
            checkStmt = conn.prepareStatement(checkQuery);
            checkStmt.setInt(1, studentID);
            rs = checkStmt.executeQuery();

            if (rs.next()) {
                request.setAttribute("errorMessage", "Student ID is already registered.");
                request.getRequestDispatcher("register.jsp").forward(request, response);
                return;
            }

            // 4. Insert new student record into 'students' table
            String insertQuery = "INSERT INTO students (student_ID, student_Fname, student_Lname, password) VALUES (?, ?, ?, ?)";
            insertStmt = conn.prepareStatement(insertQuery);
            insertStmt.setInt(1, studentID);
            insertStmt.setString(2, studentFname.trim());
            insertStmt.setString(3, studentLname.trim());
            insertStmt.setString(4, password);

            int rowsInserted = insertStmt.executeUpdate();

            if (rowsInserted > 0) {
                // Registration successful -> redirect to login page
                response.sendRedirect(request.getContextPath() + "/login.jsp?registered=true");
            } else {
                request.setAttribute("errorMessage", "Registration failed. Please try again.");
                request.getRequestDispatcher("register.jsp").forward(request, response);
            }

        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "Database error: " + e.getMessage());
            request.getRequestDispatcher("register.jsp").forward(request, response);
        } finally {
            // 5. Close database resources safely
            try {
                if (rs != null) rs.close();
                if (checkStmt != null) checkStmt.close();
                if (insertStmt != null) insertStmt.close();
                if (conn != null) conn.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.sendRedirect(request.getContextPath() + "/register.jsp");
    }
}