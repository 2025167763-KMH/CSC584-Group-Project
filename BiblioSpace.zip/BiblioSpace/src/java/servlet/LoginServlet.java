package servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "LoginServlet", urlPatterns = {"/LoginServlet"})
public class LoginServlet extends HttpServlet {

    // Match the exact same NetBeans Java DB settings as registerServlet.java
    private static final String DB_URL = "jdbc:derby://localhost:1527/BiblioDB";
    private static final String DB_USER = "Biblio";
    private static final String DB_PASSWORD = "password";

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String studentIDStr = request.getParameter("studentID");
        String password = request.getParameter("password");

        int studentID;
        try {
            studentID = Integer.parseInt(studentIDStr.trim());
        } catch (NumberFormatException e) {
            request.setAttribute("errorMessage", "Invalid Student ID format.");
            request.getRequestDispatcher("login.jsp").forward(request, response);
            return;
        }

        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            // Check student_ID and password in 'students' table
            String sql = "SELECT student_ID, student_Fname, student_Lname FROM students WHERE student_ID = ? AND password = ?";
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, studentID);
            stmt.setString(2, password);
            rs = stmt.executeQuery();

            if (rs.next()) {
                // Login successful -> save student details in session
                HttpSession session = request.getSession();
                session.setAttribute("student_ID", rs.getInt("student_ID"));
                session.setAttribute("student_Fname", rs.getString("student_Fname"));
                session.setAttribute("student_Lname", rs.getString("student_Lname"));

                // Redirect to dashboard.jsp
                response.sendRedirect(request.getContextPath() + "/dashboard.jsp");
            } else {
                // Invalid credentials -> return to login.jsp with error
                request.setAttribute("errorMessage", "Invalid Student ID or Password.");
                request.getRequestDispatcher("login.jsp").forward(request, response);
            }

        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "Database error: " + e.getMessage());
            request.getRequestDispatcher("login.jsp").forward(request, response);
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.sendRedirect(request.getContextPath() + "/login.jsp");
    }
}