<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="java.sql.*"%>
<%
    // Redirect to login if not logged in
    if (session.getAttribute("student_ID") == null) {
        response.sendRedirect(request.getContextPath() + "/login.jsp");
        return;
    }
%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>New Booking - Biblio-Space</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/bootstrap.min.css">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/font-awesome-4.7.0/css/font-awesome.min.css">
    <style>
        body { margin: 0; font-family: Arial, sans-serif; background-color: #f5f5f5; color: #333; }
        .header { background-color: white; height: 60px; display: flex; align-items: center; justify-content: space-between; padding: 0 15px; border-bottom: 1px solid #ddd; }
        .logo { display: flex; align-items: center; font-size: 18px; font-weight: bold; color: #333; text-decoration: none; }
        .logo img { width: 30px; height: 30px; margin-right: 8px; }
        .banner { background-color: #1b2b3a; color: white; padding: 18px 15px; font-size: 18px; }
        .container-box { max-width: 500px; margin: 30px auto; background: white; padding: 25px; border-radius: 8px; border: 1px solid #ddd; box-shadow: 0 2px 8px rgba(0,0,0,0.08); }
        .form-group { margin-bottom: 15px; }
        label { font-weight: bold; font-size: 13px; display: block; margin-bottom: 5px; }
        select, input[type="date"], input[type="time"] { width: 100%; padding: 9px; border: 1px solid #ccc; border-radius: 4px; font-size: 13px; box-sizing: border-box; }
        .btn-submit { width: 100%; padding: 10px; background-color: #ff5a5f; color: white; border: none; border-radius: 4px; font-weight: bold; cursor: pointer; font-size: 14px; }
        .btn-submit:hover { background-color: #e0484d; }
        .alert-error { background: #f8d7da; color: #721c24; padding: 10px; border-radius: 4px; margin-bottom: 15px; font-size: 13px; }
        .footer { background-color: #1b2b3a; color: white; text-align: center; padding: 15px; font-size: 11px; margin-top: 40px; }
    </style>
</head>
<body>

    <div class="header">
        <a href="${pageContext.request.contextPath}/dashboard.jsp" class="logo">
            <img src="${pageContext.request.contextPath}/img/icons8-meeting-room-50.png" alt="Logo">
            Biblio-Space
        </a>
        <a href="${pageContext.request.contextPath}/dashboard.jsp" class="btn btn-sm btn-outline-secondary">Back to Dashboard</a>
    </div>

    <div class="banner">Reserve a Discussion Room</div>

    <div class="container-box">
        <% if (request.getAttribute("errorMessage") != null) { %>
            <div class="alert-error"><%= request.getAttribute("errorMessage") %></div>
        <% } %>

        <form action="${pageContext.request.contextPath}/BookingServlet" method="post">
            <div class="form-group">
                <label for="room_ID">Select Room</label>
                <select id="room_ID" name="room_ID" required>
                    <option value="">-- Choose a Room --</option>
                    <%
                        try {
                            Class.forName("org.apache.derby.jdbc.ClientDriver");
                            Connection conn = DriverManager.getConnection("jdbc:derby://localhost:1527/BiblioDB", "Biblio", "password");
                            Statement stmt = conn.createStatement();
                            ResultSet rs = stmt.executeQuery("SELECT room_ID, Room_name, Room_type FROM Rooms");
                            while (rs.next()) {
                    %>
                        <option value="<%= rs.getInt("room_ID") %>">
                            <%= rs.getString("Room_name") %> (<%= rs.getString("Room_type") %>)
                        </option>
                    <%
                            }
                            rs.close(); stmt.close(); conn.close();
                        } catch (Exception e) {
                            out.println("<option disabled>Error loading rooms: " + e.getMessage() + "</option>");
                        }
                    %>
                </select>
            </div>

            <div class="form-group">
                <label for="book_date">Booking Date</label>
                <input type="date" id="book_date" name="book_date" required>
            </div>

            <div class="form-group">
                <label for="start_time">Start Time</label>
                <input type="time" id="start_time" name="start_time" required>
            </div>

            <div class="form-group">
                <label for="end_time">End Time</label>
                <input type="time" id="end_time" name="end_time" required>
            </div>

            <button type="submit" class="btn-submit">Confirm Booking</button>
        </form>
    </div>

    <div class="footer">Copyright &copy; 2026 The Library. Biblio-Space Discussion Room Booking</div>
</body>
</html>