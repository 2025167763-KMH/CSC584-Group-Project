<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="java.sql.*"%>
<%
    if (session.getAttribute("student_ID") == null) {
        response.sendRedirect(request.getContextPath() + "/login.jsp");
        return;
    }
    int studentID = (Integer) session.getAttribute("student_ID");
%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>My Booking History - Biblio-Space</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/bootstrap.min.css">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/font-awesome-4.7.0/css/font-awesome.min.css">
    <style>
        body { margin: 0; font-family: Arial, sans-serif; background-color: #f5f5f5; color: #333; }
        .header { background-color: white; height: 60px; display: flex; align-items: center; justify-content: space-between; padding: 0 15px; border-bottom: 1px solid #ddd; }
        .logo { display: flex; align-items: center; font-size: 18px; font-weight: bold; color: #333; text-decoration: none; }
        .logo img { width: 30px; height: 30px; margin-right: 8px; }
        .banner { background-color: #1b2b3a; color: white; padding: 18px 15px; font-size: 18px; }
        .main-box { max-width: 850px; margin: 30px auto; background: white; padding: 25px; border-radius: 8px; border: 1px solid #ddd; }
        .footer { background-color: #1b2b3a; color: white; text-align: center; padding: 15px; font-size: 11px; margin-top: 40px; }
    </style>
</head>
<body>

    <div class="header">
        <a href="${pageContext.request.contextPath}/dashboard.jsp" class="logo">
            <img src="${pageContext.request.contextPath}/img/icons8-meeting-room-50.png" alt="Logo">
            Biblio-Space
        </a>
        <div>
            <a href="${pageContext.request.contextPath}/booking.jsp" class="btn btn-sm btn-danger">+ New Booking</a>
            <a href="${pageContext.request.contextPath}/dashboard.jsp" class="btn btn-sm btn-outline-secondary">Dashboard</a>
        </div>
    </div>

    <div class="banner">My Booking History</div>

    <div class="main-box">
        <% if ("true".equals(request.getParameter("booked"))) { %>
            <div class="alert alert-success">Room booked successfully!</div>
        <% } %>

        <table class="table table-striped table-bordered">
            <thead class="thead-dark">
                <tr>
                    <th>Booking ID</th>
                    <th>Room</th>
                    <th>Room Type</th>
                    <th>Date</th>
                    <th>Time</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <%
                    boolean hasRows = false;
                    try {
                        Class.forName("org.apache.derby.jdbc.ClientDriver");
                        Connection conn = DriverManager.getConnection("jdbc:derby://localhost:1527/BiblioDB", "Biblio", "password");
                        String sql = "SELECT b.booking_ID, r.Room_name, r.Room_type, b.book_date, b.start_time, b.end_time, b.status " +
                                     "FROM Bookings b JOIN Rooms r ON b.room_ID = r.room_ID " +
                                     "WHERE b.student_ID = ? ORDER BY b.book_date DESC, b.start_time DESC";
                        PreparedStatement stmt = conn.prepareStatement(sql);
                        stmt.setInt(1, studentID);
                        ResultSet rs = stmt.executeQuery();

                        while (rs.next()) {
                            hasRows = true;
                            int bID = rs.getInt("booking_ID");
                            String status = rs.getString("status");
                %>
                <tr>
                    <td>#<%= bID %></td>
                    <td><%= rs.getString("Room_name") %></td>
                    <td><%= rs.getString("Room_type") %></td>
                    <td><%= rs.getDate("book_date") %></td>
                    <td><%= rs.getTime("start_time") %> - <%= rs.getTime("end_time") %></td>
                    <td>
                        <span class="badge <%= "Upcoming".equals(status) ? "badge-success" : "badge-secondary" %>">
                            <%= status %>
                        </span>
                    </td>
                    <td>
                        <% if ("Upcoming".equals(status)) { %>
                            <form action="${pageContext.request.contextPath}/CancelBookingServlet" method="post" style="margin:0;">
                                <input type="hidden" name="booking_ID" value="<%= bID %>">
                                <button type="submit" class="btn btn-sm btn-danger">Cancel</button>
                            </form>
                        <% } else { %>
                            <span class="text-muted">Closed</span>
                        <% } %>
                    </td>
                </tr>
                <%
                        }
                        rs.close(); stmt.close(); conn.close();
                    } catch (Exception e) {
                        out.println("<tr><td colspan='7'>Error: " + e.getMessage() + "</td></tr>");
                    }
                    if (!hasRows) {
                %>
                <tr>
                    <td colspan="7" class="text-center text-muted">No bookings found yet. Click "+ New Booking" to reserve a room!</td>
                </tr>
                <% } %>
            </tbody>
        </table>
    </div>

    <div class="footer">Copyright &copy; 2026 The Library. Biblio-Space Discussion Room Booking</div>
</body>
</html>