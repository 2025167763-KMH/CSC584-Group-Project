<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Register Page - Biblio-Space</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet"
          href="${pageContext.request.contextPath}/css/bootstrap.min.css">

    <style>
        /* Basic page settings */
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: #eeeeee;
        }

        /* Top bar */
        .top-bar {
            height: 35px;
            background-color: #222222;
            color: white;
            padding: 8px 15px;
            font-size: 12px;
        }

        .top-bar a {
            float: right;
            color: white;
            text-decoration: none;
            background-color: #555555;
            padding: 3px 8px;
            border-radius: 5px;
            margin-left: 8px;
        }

        .top-bar a:hover {
            background-color: #ff3344;
        }

        /* Main background section */
        .register-section {
            position: relative;
            min-height: 500px;
            padding: 30px 0;
            display: flex;
            justify-content: center;
            align-items: center;
            overflow: hidden;
        }

        /* Blurred library background */
        .register-section::before {
            content: "";
            position: absolute;
            top: -10px;
            left: -10px;
            right: -10px;
            bottom: -10px;
            background-image: url('${pageContext.request.contextPath}/img/bg-img-1.jpg');
            background-size: cover;
            background-position: center;
            filter: blur(4px);
            z-index: 0;
        }

        /* Dark layer over background */
        .register-section::after {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.25);
            z-index: 1;
        }

        /* White register box */
        .register-box {
            position: relative;
            z-index: 2;
            width: 330px;
            padding: 25px;
            background-color: white;
            border-radius: 5px;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.2);
        }

        /* Register heading */
        .register-box h2 {
            text-align: center;
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 18px;
            color: #333333;
        }

        /* Error Alert Message */
        .alert-error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
            padding: 8px;
            margin-bottom: 12px;
            border-radius: 4px;
            font-size: 12px;
            text-align: center;
        }

        /* Input labels */
        .register-box label {
            display: block;
            font-size: 12px;
            font-weight: bold;
            margin-bottom: 4px;
            color: #333333;
        }

        /* Input fields */
        .register-box input {
            width: 100%;
            padding: 8px;
            margin-bottom: 12px;
            border: 1px solid #cccccc;
            border-radius: 4px;
            font-size: 12px;
            box-sizing: border-box;
        }

        /* Red register button */
        .register-button {
            width: 100%;
            padding: 9px;
            background-color: #ff3344;
            color: white;
            border: none;
            border-radius: 3px;
            font-size: 13px;
            font-weight: bold;
            cursor: pointer;
            margin-top: 5px;
        }

        /* Button hover effect */
        .register-button:hover {
            background-color: #dd2233;
        }

        /* Login redirect link */
        .login-link {
            display: block;
            text-align: center;
            margin-top: 14px;
            font-size: 11px;
            color: #333333;
            text-decoration: none;
        }

        .login-link:hover {
            color: #ff3344;
            text-decoration: underline;
        }

        /* Bottom footer */
        .footer {
            background-color: #1b2b3a;
            color: white;
            text-align: center;
            padding: 15px;
            font-size: 10px;
        }

        /* Adjust for smaller screens */
        @media screen and (max-width: 480px) {
            .register-box {
                width: 85%;
                padding: 20px;
            }
        }
    </style>
</head>

<body>

    <!-- Top Bar -->
    <div class="top-bar">
        Biblio-Space
        <a href="${pageContext.request.contextPath}/login.jsp">Login</a>
        <a href="${pageContext.request.contextPath}/index.jsp">Home</a>
    </div>

    <!-- Register Section -->
    <div class="register-section">

        <div class="register-box">

            <h2>Register</h2>

            <!-- Display Error Message from Servlet if any -->
            <% if (request.getAttribute("errorMessage") != null) { %>
                <div class="alert-error">
                    <%= request.getAttribute("errorMessage") %>
                </div>
            <% } %>

            <!-- Registration Form -->
            <form action="${pageContext.request.contextPath}/registerServlet" method="post">

                <!-- Student ID (int PK) -->
                <label for="student_ID">Student ID</label>
                <input type="number"
                       id="student_ID"
                       name="student_ID"
                       placeholder="e.g. 2026123456"
                       required>

                <!-- First Name (student_Fname) -->
                <label for="student_Fname">First Name</label>
                <input type="text"
                       id="student_Fname"
                       name="student_Fname"
                       placeholder="First Name"
                       required>

                <!-- Last Name (student_Lname) -->
                <label for="student_Lname">Last Name</label>
                <input type="text"
                       id="student_Lname"
                       name="student_Lname"
                       placeholder="Last Name"
                       required>

                <!-- Password -->
                <label for="password">Password</label>
                <input type="password"
                       id="password"
                       name="password"
                       placeholder="Password"
                       required>

                <!-- Confirm Password -->
                <label for="confirmPassword">Confirm Password</label>
                <input type="password"
                       id="confirmPassword"
                       name="confirmPassword"
                       placeholder="Confirm Password"
                       required>

                <!-- Register Button -->
                <button type="submit" class="register-button">
                    Register
                </button>

            </form>

            <!-- Redirect to Login -->
            <a href="${pageContext.request.contextPath}/login.jsp" class="login-link">
                Already have an account? Log In
            </a>

        </div>

    </div>

    <!-- Footer -->
    <div class="footer">
        Copyright &copy; 2026 Biblio-Space.
        All rights reserved.
    </div>

