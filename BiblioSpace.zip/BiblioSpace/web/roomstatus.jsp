<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="java.sql.*"%>
<%@page import="java.util.*"%>
<%@page import="java.text.SimpleDateFormat"%>
<jsp:include page="includes/header.jsp" />

<%
    // 1. Get filter parameters (default date = today, default roomType = ALL)
    String selectedDate = request.getParameter("date");
    if (selectedDate == null || selectedDate.trim().isEmpty()) {
        selectedDate = new SimpleDateFormat("yyyy-MM-dd").format(new java.util.Date());
    }
    String selectedType = request.getParameter("roomType");
    if (selectedType == null || selectedType.trim().isEmpty()) {
        selectedType = "ALL";
    }

    String dbUrl = "jdbc:derby://localhost:1527/BiblioDB";
    String dbUser = "Biblio";
    String dbPass = "password";

    List<String> roomTypes = new ArrayList<String>();
    // Each room: [room_ID, Room_name, Room_type]
    List<String[]> roomsList = new ArrayList<String[]>();
    // Map: room_ID -> List of [startHour, endHour] for Upcoming bookings on selectedDate
    Map<Integer, List<int[]>> bookedSlots = new HashMap<Integer, List<int[]>>();

    try {
        Class.forName("org.apache.derby.jdbc.ClientDriver");
        Connection conn = DriverManager.getConnection(dbUrl, dbUser, dbPass);

        // Fetch distinct room types for dropdown
        Statement typeStmt = conn.createStatement();
        ResultSet typeRs = typeStmt.executeQuery("SELECT DISTINCT Room_type FROM Rooms");
        while (typeRs.next()) {
            roomTypes.add(typeRs.getString("Room_type"));
        }
        typeRs.close();
        typeStmt.close();

        // Fetch rooms matching selected roomType
        PreparedStatement roomStmt;
        if ("ALL".equals(selectedType)) {
            roomStmt = conn.prepareStatement("SELECT room_ID, Room_name, Room_type FROM Rooms ORDER BY room_ID");
        } else {
            roomStmt = conn.prepareStatement("SELECT room_ID, Room_name, Room_type FROM Rooms WHERE Room_type = ? ORDER BY room_ID");
            roomStmt.setString(1, selectedType);
        }
        ResultSet roomRs = roomStmt.executeQuery();
        while (roomRs.next()) {
            roomsList.add(new String[]{
                String.valueOf(roomRs.getInt("room_ID")),
                roomRs.getString("Room_name"),
                roomRs.getString("Room_type")
            });
        }
        roomRs.close();
        roomStmt.close();

        // Fetch all Upcoming bookings on selectedDate
        PreparedStatement bookStmt = conn.prepareStatement(
            "SELECT room_ID, start_time, end_time FROM Bookings WHERE book_date = ? AND status = 'Upcoming'"
        );
        bookStmt.setDate(1, java.sql.Date.valueOf(selectedDate));
        ResultSet bookRs = bookStmt.executeQuery();
        while (bookRs.next()) {
            Integer rId = Integer.valueOf(bookRs.getInt("room_ID"));
            Time sTime = bookRs.getTime("start_time");
            Time eTime = bookRs.getTime("end_time");

            Calendar calStart = Calendar.getInstance();
            calStart.setTime(sTime);
            int startHour = calStart.get(Calendar.HOUR_OF_DAY);

            Calendar calEnd = Calendar.getInstance();
            calEnd.setTime(eTime);
            int endHour = calEnd.get(Calendar.HOUR_OF_DAY);
            if (calEnd.get(Calendar.MINUTE) > 0) {
                endHour += 1; // Round partial end hour up to cover the slot
            }

            List<int[]> list = bookedSlots.get(rId);
            if (list == null) {
                list = new ArrayList<int[]>();
                bookedSlots.put(rId, list);
            }
            list.add(new int[]{startHour, endHour});
        }
        bookRs.close();
        bookStmt.close();
        conn.close();
    } catch (Exception e) {
        out.println("<div class='container mt-3'><div class='alert alert-danger'>Database Error: " + e.getMessage() + "</div></div>");
    }
%>

<style>
    .status-container {
        max-width: 1150px;
        margin: 35px auto;
        padding: 0 15px;
    }
    .filter-card {
        background: #ffffff;
        border: 1px solid #e0e0e0;
        border-radius: 8px;
        padding: 20px;
        margin-bottom: 25px;
        box-shadow: 0 2px 6px rgba(0,0,0,0.05);
    }
    .legend-box {
        display: inline-flex;
        align-items: center;
        margin-right: 20px;
        font-size: 13px;
        font-weight: 600;
    }
    .legend-color {
        width: 16px;
        height: 16px;
        border-radius: 4px;
        display: inline-block;
        margin-right: 6px;
    }
    .timeline-table th, .timeline-table td {
        text-align: center;
        vertical-align: middle !important;
        font-size: 12px;
        padding: 10px 4px !important;
    }
    .room-col {
        text-align: left !important;
        min-width: 170px;
        padding-left: 12px !important;
        background-color: #fafafa;
    }
    .slot-available {
        background-color: #d4edda !important;
        color: #155724;
        font-weight: bold;
    }
    .slot-reserved {
        background-color: #f8d7da !important;
        color: #721c24;
        font-weight: bold;
    }
</style>

<div class="status-container">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2 class="font-weight-bold" style="color: #1b2b3a; margin: 0;">Room Status & Availability</h2>
        <a href="${pageContext.request.contextPath}/booking.jsp" class="btn btn-danger" style="background-color: #ff5a5f; border-color: #ff5a5f;">
            <i class="fa fa-calendar-plus-o"></i> Reserve a Room
        </a>
    </div>

    <!-- Search Controls: Date Picker & Room Type Dropdown -->
    <div class="filter-card">
        <form method="get" action="${pageContext.request.contextPath}/roomstatus.jsp" class="row align-items-end">
            <div class="col-md-4 mb-2 mb-md-0">
                <label for="date" class="font-weight-bold" style="font-size: 13px;">Select Date</label>
                <input type="date" id="date" name="date" class="form-control" value="<%= selectedDate %>" required>
            </div>

            <div class="col-md-4 mb-2 mb-md-0">
                <label for="roomType" class="font-weight-bold" style="font-size: 13px;">Room Type</label>
                <select id="roomType" name="roomType" class="form-control">
                    <option value="ALL" <%= "ALL".equals(selectedType) ? "selected" : "" %>>All Room Types</option>
                    <% for (int i = 0; i < roomTypes.size(); i++) {
                        String type = roomTypes.get(i);
                    %>
                        <option value="<%= type %>" <%= type.equals(selectedType) ? "selected" : "" %>><%= type %></option>
                    <% } %>
                </select>
            </div>

            <div class="col-md-4">
                <button type="submit" class="btn btn-dark btn-block" style="background-color: #1b2b3a;">
                    <i class="fa fa-search"></i> Check Availability
                </button>
            </div>
        </form>
    </div>

    <!-- Status Legend -->
    <div class="mb-3">
        <span class="legend-box">
            <span class="legend-color" style="background-color: #d4edda; border: 1px solid #c3e6cb;"></span> Available
        </span>
        <span class="legend-box">
            <span class="legend-color" style="background-color: #f8d7da; border: 1px solid #f5c6cb;"></span> Reserved
        </span>
        <span class="text-muted" style="font-size: 13px;">Showing schedule for: <strong><%= selectedDate %></strong></span>
    </div>

    <!-- Visual Timeline Grid (8:00 AM to 10:00 PM) -->
    <div class="table-responsive" style="background: white; border-radius: 8px; box-shadow: 0 2px 6px rgba(0,0,0,0.05);">
        <table class="table table-bordered timeline-table mb-0">
            <thead style="background-color: #1b2b3a; color: white;">
                <tr>
                    <th class="room-col" style="background-color: #1b2b3a; color: white;">Room Name</th>
                    <%
                        // Operating hours: 8:00 AM (8) to 10:00 PM (22 -> last slot 21:00-22:00)
                        for (int h = 8; h < 22; h++) {
                            String label = (h < 12) ? (h + " AM") : (h == 12 ? "12 PM" : ((h - 12) + " PM"));
                    %>
                        <th><%= label %></th>
                    <% } %>
                </tr>
            </thead>
            <tbody>
                <%
                    if (roomsList.isEmpty()) {
                %>
                    <tr>
                        <td colspan="15" class="text-center text-muted py-4">
                            No rooms found. Make sure you have inserted rooms into the <strong>Rooms</strong> table.
                        </td>
                    </tr>
                <%
                    } else {
                        for (int r = 0; r < roomsList.size(); r++) {
                            String[] room = roomsList.get(r);
                            Integer rId = Integer.valueOf(Integer.parseInt(room[0]));
                            String rName = room[1];
                            String rType = room[2];
                            List<int[]> intervals = bookedSlots.get(rId);
                            if (intervals == null) {
                                intervals = Collections.emptyList();
                            }
                %>
                    <tr>
                        <td class="room-col">
                            <strong><%= rName %></strong><br>
                            <small class="text-muted"><%= rType %></small>
                        </td>
                        <%
                            for (int h = 8; h < 22; h++) {
                                boolean isReserved = false;
                                for (int j = 0; j < intervals.size(); j++) {
                                    int[] interval = intervals.get(j);
                                    if (h >= interval[0] && h < interval[1]) {
                                        isReserved = true;
                                        break;
                                    }
                                }
                        %>
                            <td class="<%= isReserved ? "slot-reserved" : "slot-available" %>"
                                title="<%= isReserved ? "Reserved" : "Available" %>">
                                <%= isReserved ? "Reserved" : "Free" %>
                            </td>
                        <% } %>
                    </tr>
                <%
                        }
                    }
                %>
            </tbody>
        </table>
    </div>
</div>

<jsp:include page="includes/footer.jsp" />